# Recruitment SaaS UI — Build Plan

Minimal, enterprise-grade recruitment app inspired by Linear/Monday/Notion. Frontend only, in-memory sample data (no backend). If you later want persistence, we can enable Lovable Cloud.

## Design system
- Clean white UI, subtle gray surfaces, rounded corners, soft borders, modern sans typography (Inter-ish via system stack), semantic tokens in `src/styles.css` (no hardcoded colors).
- Primary accent: neutral indigo/near-black (Linear-like). Status colors as semantic tokens.

## Layout shell (`src/routes/_app.tsx` layout)
- **Left sidebar**: Job Requisitions, Vacancies, Candidates, Interviews, Job Offers, Talent Pool (visible, empty placeholder).
- **Top bar**: search (contextual), Notifications icon, User profile icon.
- Routes:
  - `/requisitions`, `/vacancies`, `/candidates`, `/interviews`, `/offers`, `/talent-pool`
  - `/{section}/:id` for detail pages
  - `/` redirects to `/requisitions`

## Section list pages (shared component)
- View tabs: **List** | **Board**
- Search bar, "Create" button (opens modal with section-specific fields)
- **List view** columns: ID, Title, Stage/Status, Created by, Create date, Assigned
- **Board view**: Kanban columns from that section's statuses (drag to change status)
- Candidates page: extra "Vacancy" filter dropdown, default-filtered
- Double-click row/card → detail page

## Statuses per section
- Requisitions: Draft, Pending, Approved, Rejected, Completed, Cancelled
- Vacancies: Opened, Cancelled, Completed
- Candidates: Applied, Resume Review, Technical Interview, HR Interview, Interviewed, Hired, Rejected, Withdrawn
- Interviews: Scheduled, Completed, Cancelled
- Offers: Sent, Rejected, Cancelled, Accepted

## Detail page tabs
- **Overview**: editable fields per section (see spec) + Comments/chat panel with @mentions and emoji picker
- **Related with**: grouped lists of related items (Requisition→Vacancies→Candidates→Interviews/Offers)
- **Approvals**: list existing (Sent by, Approved by, Date, Status, Note) + add new approvers (Approver dropdown, Order, Note, Required/Optional). Approve/Reject with note. Demoed on a sample candidate.
- **Activity**: timeline of changes (sample data)
- **Attachments**: file list with preview
- **Mails** (Candidates only): thread-style mail list

## Create modals (per-section field lists from spec)
- Contextual "Create Vacancy" inside Requisition detail, "Create Candidate" inside Vacancy, "Create Interview" / "Create Job Offer" inside Candidate.
- CV: show as opened preview (embedded viewer stub).

## Sample data
- Seed 5–8 items per section with realistic names, cross-linked so Related tab works.
- In-memory Zustand store (or React context) so edits/creates persist during session.

## Technical notes
- TanStack Router file-based routes under `src/routes/`
- Layout route: `src/routes/_app.tsx` wraps all sections with sidebar + topbar
- Shared components: `SectionListPage`, `KanbanBoard`, `DetailPage`, `CreateDialog`, field renderers
- shadcn/ui for tables, tabs, dialogs, dropdowns, select, avatar, badges
- Drag-and-drop Kanban via `@dnd-kit/core`
- State: Zustand store per section with sample seed data
- No auth, no backend in v1

## Out of scope (v1)
- Real backend/persistence, real email sending, real file uploads (previews are stubbed), real auth, RBAC beyond UI.

Confirm and I'll build it.